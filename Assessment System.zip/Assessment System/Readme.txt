Team:
Abhinav Medhekar (amedhek)
Arjun Sharma (asharm33)
Kiran Krishnan Balakrishnan (kbalakr)
Samir Jha (sjha4)
Shibalik Mohapatra (smohapa3)


Steps to Run:
Unzip the submission
Go to directory Assessment System

> java -jar Assignment_Management